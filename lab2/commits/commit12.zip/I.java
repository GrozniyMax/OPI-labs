public class I extends null {

    java.util.List<String> jj();

    String nn();
}

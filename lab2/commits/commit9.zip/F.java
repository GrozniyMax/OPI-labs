public interface F {

    void aa();

    java.util.Random mm();
}

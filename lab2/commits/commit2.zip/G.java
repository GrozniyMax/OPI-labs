public class G implements F, I {

    private long d = 4321;

    private long g = 1234;

    public void ab() {
        System.out.println("\n");
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public byte oo() {
        return 3;
    }

    public double ee() {
        return 100.500;
    }
}

public interface I {

    java.util.List<String> jj();

    String nn();
}

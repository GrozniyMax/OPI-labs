public class F extends null {

    void aa();

    java.util.Random mm();
}

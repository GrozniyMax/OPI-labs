public class H implements I {

    private String i = "hello";

    private int h = 42;

    public java.lang.Class qq() {
        return getClass();
    }

    public byte oo() {
        return 2;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public void bb() {
        System.out.println(42);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public void ab() {
        System.out.println();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}

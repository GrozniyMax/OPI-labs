public class I extends null {

    java.util.List<String> jj();

    String nn();

    public Object rr() {
        return null;
    }
}

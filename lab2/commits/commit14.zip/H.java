public class H extends null implements I {

    private String i = "hello";

    private int h = 42;

    public java.lang.Class qq() {
        return getClass();
    }

    public byte oo() {
        return 2;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public void bb() {
        System.out.println(42);
    }

    public void ab() {
        System.out.println();
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int af() {
        return -1;
    }

    public float ff() {
        return 3.14;
    }

    public Object pp() {
        return this;
    }
}

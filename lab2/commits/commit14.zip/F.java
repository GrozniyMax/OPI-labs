public class F extends null {

    void aa();

    java.util.Random mm();

    public double ee() {
        return 100.500;
    }
}

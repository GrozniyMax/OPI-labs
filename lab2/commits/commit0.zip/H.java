public class H implements I {

    private String i = "hello";

    private int h = 42;

    public java.lang.Class qq() {
        return getClass();
    }

    public byte oo() {
        return 2;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
